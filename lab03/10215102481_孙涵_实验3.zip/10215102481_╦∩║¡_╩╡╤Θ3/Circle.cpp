#include "Circle.h"

std::vector<Point> DrawCircle(Point center, float radius)
{
	std::vector<Point> points;

	int cx, cy;
	float r = radius;
	cx = center.x;
	cy = center.y;
	Point draw;
	draw.x = 0;
	draw.y = r;
	Point ans;
	ans.x = draw.x + cx;
	ans.y = draw.y + cy;
	points.push_back(ans);
	float p;
	p = (5 / 4) - r;
	while (draw.x < draw.y) {
		if (p < 0) {
			draw.x = draw.x + 1;
			p = p + 2 * draw.x + 1;
		}
		if (p >= 0) {
			draw.x = draw.x + 1;
			draw.y = draw.y - 1;
			p = p + 2 * draw.x + 1 - 2 * draw.y;
		}
		ans.x = draw.x + cx;
		ans.y = draw.y + cy;
		points.push_back(ans);//���½��°�1/8Բ��
		Point val;
		val.x = ans.y + cx - cy;
		val.y = ans.x + cy - cx;
		points.push_back(val);//���½��ϰ�1/8Բ��
		val.x = 2 * cx - ans.x;
		val.y = ans.y;
		points.push_back(val);//���½��°�1/8Բ��
		int temp = val.x;
		val.x = cx + cy - val.y;
		val.y = cx + cy - temp;
		points.push_back(val);//���½��ϰ�1/8Բ��
		temp = val.x;
		val.x = val.y + cx - cy;
		val.y = temp + cy - cx;
		points.push_back(val);//���Ͻ��ϰ�1/8Բ��
		temp = val.x;
		val.x = cx + cy - val.y;
		val.y = cx + cy - temp;
		points.push_back(val);//���Ͻ��°�1/8Բ��
		val.x = cx + cy - ans.y;
		val.y = cx + cy - ans.x;
		points.push_back(val);//���Ͻ��°�1/8Բ��
		temp = val.x;
		val.x = val.y + cx - cy;
		val.y = temp + cy - cx;
		points.push_back(val);//���Ͻ��ϰ�1/8Բ��
	}
	return points;
}

