#include "Bezier.h"

std::vector<Point> Bezier(std::vector<Point> anchorPoints)
{
	std::vector<Point> result;

	std::vector<Point> temp = anchorPoints;
	Point ans;
	int n = anchorPoints.size();
	for (float t = 0.0; t <= 1; t += 0.000001) {
		for (int i = 1; i < n; i++) {
			for (int j = 0; j < n - i; j++) {
				temp[j].x = (1 - t) * temp[j].x + t * temp[j + 1].x;
				temp[j].y = (1 - t) * temp[j].y + t * temp[j + 1].y;
			}
		}
		ans.x = temp[0].x;
		ans.y = temp[0].y;
		result.push_back(ans);
	}


	return result;
}