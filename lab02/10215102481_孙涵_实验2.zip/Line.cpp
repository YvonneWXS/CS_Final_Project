#include "Line.h"

std::vector<Point> DDADrawLine(Point beginPoint, Point endPoint)
{
    // @TODO implement DDA draw line algorithm here.
    /*
    draw line between beginPoint and endPoint
    save all points into result
    */
    std::vector<Point> result;
    double k, x, y, deltaX, deltaY;
    Point draw;//Ҫ�Ž�vector�ĵ�
    deltaX = double(endPoint.x - beginPoint.x);
    deltaY = double(endPoint.y - beginPoint.y);
    x = beginPoint.x; 
    y = beginPoint.y;
    k = deltaY / deltaX;
    if (abs(k) <= 1) {  
        if (deltaX >= 0) {  //xԽ��Խ�����������ӷ�����
            for (x = beginPoint.x; x <= endPoint.x; x++) {
                draw.x = x; 
                draw.y = int(y + 0.5);  //y��������
                result.push_back(draw);
                y = y + k;
            }
        }
        else if (deltaX < 0) {  //xԽ��ԽС��������������
            for (x = beginPoint.x; x >= endPoint.x; x--) {
                draw.x = x; 
                draw.y = int(y + 0.5);//y��������
                result.push_back(draw);
                y = y - k;
            }
        }
    }
    else {
        k = deltaX / deltaY;  //��k��Ϊ1/k�����ҽ�x��y�ļ�����򻥻�
        if (deltaY >= 0) {  //yԽ��Խ�����������ӷ�����
            for (y = beginPoint.y; y <= endPoint.y; y++) {
                draw.x = int(x + 0.5); //��x��������
                draw.y = y;
                result.push_back(draw);
                x = x + k;
            }
        }
        else if (deltaY < 0) {  //yԽ��ԽС��������������
            for (y = beginPoint.y; y >= endPoint.y; y--) {
                draw.x = int(x + 0.5); //��x��������
                draw.y = y;
                result.push_back(draw);
                x = x - k;
            }
        }
    }
    return result;
}

std::vector<Point> BresenhamDrawLine(Point beginPoint, Point endPoint)
{
    // @TODO implement Bresenham draw line algorithm here.
    /*
      draw line between beginPoint and endPoint
      save all points into result
    */

    std::vector<Point> result;
    int x, y;
    double k, deltaX, deltaY, d;
    Point a;
    deltaX = double(endPoint.x - beginPoint.x);
    deltaY = double(endPoint.y - beginPoint.y);
    x = beginPoint.x;
    y = beginPoint.y;
    k = deltaY / deltaX;
    if (abs(k) < 1) {
        if (deltaX >= 0 && k >= 0) {
            d = 0.5 - k;
            result.push_back({ 0,0 });
            for (x = beginPoint.x + 1; x <= endPoint.x; x++) {
                if (d < 0) {  //yȡy+1
                    y = y + 1;
                    d = d + 1 - k;  //��d��ֵ������һ������(d<0�����)
                }
                else d = d - k;  //y����ȡy,d>=0�ݹ�
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
        else if (deltaX >= 0 && k <= 0) { 
            d = 0.5 + k;
            result.push_back({ 0,0 });
            for (x = beginPoint.x + 1; x <= endPoint.x; x++) {
                if (d < 0) {  //yȡy-1
                    y = y -  1;
                    d = d + 1 + k;  //d�ĵݹ�(d<0)
                }
                else d = d + k;  //yȡ����,d�ݹ���d>=0�����
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
        //xԽ��ԽС����x��ÿһ�������Ϊ��������
        else if (deltaX <= 0 && k >= 0) {
            d = 0.5 - k;
            result.push_back({ 0,0 });
            for (x = beginPoint.x - 1; x >= endPoint.x; x--) {
                if (d < 0) {  //y-1,d�ݹ� <0 ��һ��ȥk
                    y = y - 1;
                    d = d + 1 - k;
                }
                else d = d - k;  //d>=0 y����ȡy d-k
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
        else {  //k�������ı�
            d = 0.5 + k;
            result.push_back({ 0,0 });
            for (x = beginPoint.x - 1; x >= endPoint.x; x--) {
                if (d < 0) {  //y+1,d<0 d -> d+1+k
                    y = y + 1;
                    d = d + 1 + k;
                }
                else d = d + k;  //y���� d -> d+k
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
    }
    //��������k�����1/k
    else {
        k = 1 / k;
        if (deltaY >= 0 && k >= 0) {
            d = 0.5 - k;
            result.push_back({ 0,0 });
            for (y = beginPoint.y + 1; y <= endPoint.y; y++) {
                if (d < 0) {  //x+1 d<0 d+1
                    x = x + 1;
                    d = d + 1 - k;  //d�ĵݹ����
                }
                else d = d - k;  //x = x, d>=0 dֱ�ӼӼ�k
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
        else if (deltaY >= 0 && k <= 0) {
            d = 0.5 + k;
            result.push_back({ 0,0 });
            for (y = beginPoint.y + 1; y <= endPoint.y; y++) {
                if (d < 0) {  //x-1 d<0 d+1�ټ�k
                    x = x - 1;
                    d = d + 1 + k;
                }
                else d = d + k;  //x���� d>0 dֱ�Ӽ�k
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
        else if (deltaY <= 0 && k >= 0) {
            d = 0.5 - k;
            result.push_back({ 0,0 });
            for (y = beginPoint.y - 1; y >= endPoint.y; y--) {
                if (d < 0) { 
                    x = x - 1;
                    d = d + 1 - k;
                }
                else d = d - k;
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
        else {
            d = 0.5 + k;
            result.push_back({ 0,0 });
            for (y = beginPoint.y - 1; y >= endPoint.y; y--) {
                if (d < 0) {  //xȡx+1
                    x = x + 1;
                    d = d + 1 + k;
                }
                else d = d + k;  //xȡ����
                a.x = x; 
                a.y = y;
                result.push_back(a);
            }
        }
    }
    return result;
}

